<?php
session_start();
$conn = mysqli_connect('localhost','root','','fyp');
if(!isset($_SESSION['admin'])){
  header('location: login.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
    <style>
      .box{
        box-shadow: 10px 10px 10px lightgray;
        border: 0px solid;
        height: auto;
      }
      footer{
          background-image: url("footer-img.jpg");
          background-repeat: no-repeat;
          background-size: 100% 87%;
        }
        .card {
    width: 300px;
    margin: 10px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card-image {
    width: 100%;
    height: auto;
    border-radius: 5px;
    margin-bottom: 10px;
}

.card-title {
    font-size: 18px;
    margin-top: 0;
}

.card-info {
    margin-bottom: 5px;
}
      
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Online Property</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="property.php">Projects</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="map.php">House Plan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="developer.php">developer</a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link" href="#">Investment</a>
            </li> -->
            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                type
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li> -->
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="login.php">Log Out</a></button>
          </form>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="list property.php">List Property</a></button>
          </form>
        </div>
      </nav>
  <!-- <div class="container mx-auto w-75 col-lg-12 col-sm-12">
        <div class="row">
          <div class="col-lg-8 col-md-12 col-sm-12 col-xm-12">
            <h1 class="text-responsive">850 Sqft Office For Sales In Gulshan-E-Iqbal, Karachi</h1>
            <p>Main University Road, Opp.Federal Urdu University, Gulshan e Iqbal Block 13 C</p>
            <video width="100%" controls>
                <source src="https://youtu.be/tMB_-0AwYcQ" type="video/mp4">
                Your browser does not support HTML video.
            </video>
         </div>
          <div>
            
          </div>
        </div>
        <div class="container mx-auto col-lg-12 col-sm-12">
          <h2><span style="font-size: 20px;">pkr</span> 55 Thousand</h2>
        </div>
      </div>

      <br>
      <div class="box col-lg-12 col-sm-12 w-75 mx-auto m-4">
        <div class="row">
            <div class="col-lg-4 col-sm-12 p-4">
              <h2>Project Detail</h2>
            </div>
            <div class="col-lg-4 col-sm-12 p-4">
              <h2>Project id: 3</h2>
            </div>
            <div class="col-lg-4 col-sm-12 p-4">
              <h2>Price: 3000</h2>
            </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-lg-4 col-sm-12">
            <h2>Description</h2>
          </div>
          <div class="col-lg-7 col-sm-12">
            <p>Noble Group is an adorable and trustworthy facilitator in the real estate world.
                After giving so many successful projects in Karachi now they are presenting the 
                sublime Sohni Saibaan apartment, a radiant reliable residence & commercial tower.
                  Sohni Saibaan is located in Scheme 33 near Jamali Pull adjacent Gulzar-e-Hijri.
                  Famous restaurants, schools, hospitals, marts & banks. Scheme 33 is the hotspot
                    of real estate development in Karachi equipped with all the necessary amenities
                    for living. The land is on 1.6 acres and has 408 residential units and 17 commercial.
                      The plaza is an ideal place to live as it has a west open each apartment is corner
                      and is park-facing. The ultra-modern design building has wide space floors
                        furnished with marble and tiles. The leakage-proof tower and ventilation system.
                        3 & 4 bedrooms luxury apartments along with a rooftop garden. American-style kitchen,
                          luxury-styled living areas, and drawing room. Sohni Saibaan is the most luxurious
                          apartment in this vicinity. The commercial outlets are designed smartly with wide
                            space to showcase the product or business vigilantly. Superfast elevators,
                            indoor parking, a play area for kids, courtyard some are essentials for making
                              this project an emblem of the top level of affluence. Salient features:
                Luxury Apartments Marble Floored Corridors Courtyard
                Play Ground All Apartments Corner Apartments Accessibility Indoor Parking Commercial Outlets Rooftop Gardens.
              </p>
          </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-lg-4 col-sm-12">
            <h2>Features</h2>
          </div>
          <div class="col-lg-8 col-sm-12">
            <h5><u>Amenity Details</u></h5>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-droplet"> water</i>
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-fire"> Gas</i>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-square-parking"> parking area</i>
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-bolt-lightning"> Electricity</i>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-road"> road</i>
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-person-military-pointing"> Security Staff</i>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-video"> CCTV Cameras</i>
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-globe"> tv and internet</i>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <h5><u>Nearby Details</u></h5>
          </div>
          <div class="col-lg-4 col-sm-12">
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-regular fa-hospital fa-solid"> hospital</i>
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-mosque"> Masjid</i>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-school"> School</i>
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-school"> College</i>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <i class="fa-solid fa-bus"> Public Transport</i>
          </div>
          <div class="col-lg-4 col-sm-12">
          </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-lg-4 col-sm-12">  
            <h3>Address</h3>
          </div>
          <div class="col-lg-4 col-sm-12">
            <h5>Address: </h5>Scheme 33, Karachi
          </div>
          <div class="col-lg-4 col-sm-12">
            <h5>City: </h5><p>karachi</p>
          </div>
          <br><br>
          <div class="col-lg-4 col-sm-12">  
          </div>
          <div class="col-lg-4 col-sm-12">
            <h5>Area: </h5>Scheme 33
          </div>
          <div class="col-lg-4 col-sm-12">
            <h5>Country: </h5><p>Pakistan</p>
          </div>
        </div>
        <hr>
        <br><br>
        <div class="row">
          <div class="col-lg-4 col-sm-12">
            <h3>Project video</h3>
          </div>
          <div class="col-lg-8 col-sm-12 col-xm-12">
            <video width="100%" controls>
              <source src="https://youtu.be/qSJtjpfBJ5M" type="video/mp4">
              Your browser does not support HTML video.
          </video>
          </div>
        </div>
        <hr>
        <br><br>
        <div class="row">
          <div class="col-lg-4 col-sm-12">
            <h3>map</h3>
          </div>
          <div class="col-lg-8 col-sm-12 col-xm-12">
            <p><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7234.484810979209!2d67.135056!3d24.957866!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3477dc2d48907%3A0xc2bf904859fb0d9!2sLawyers&#39;%20Colony%20Karachi%20Bar%20Chs%20Sector%2024%20A%20Gulshan-e-Iqbal%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2sus!4v1673201704173!5m2!1sen!2sus"
               width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe></p>
          </video>
          </div>
        </div>
        <hr>
        <br><br>
        <div class="row">
          <div class="col-lg-4 col-sm-12">
            <h2>Enter Review</h2>
          </div>
          <div class="col-lg-8">
            <textarea style="width: 100%;" name="" id="" cols="30" rows="6"></textarea>
          </div>
        </div>
      </div> -->

      <?php
      $id =$_GET['id'];
      $q = "SELECT * FROM lpro WHERE `id`='$id'";
      $qr = mysqli_query($conn, $q);

echo "<div class='card-container col-md-8 m-auto'>";

while ($row = mysqli_fetch_assoc($qr)) {
    echo "<div class='container mt-5 mb-5 '>";
    echo "<h3 class='card-title text-uppercase'>" . $row["title"] . "</h3>";
    echo "<img class='w-50 h-50'' src='images/" . $row["file"] . "' alt='" . $row["file"] . "' class='card-image'>";
    echo "<div class='card-content'>";
    echo "<p class='card-info'><strong>ID:</strong> " . $row["id"] . "</p>";
    echo "<p class='card-info'><strong>Price:</strong> " . $row["price"] . "</p>";
    echo "<p class='card-infopr-5 pr-5'><strong>Discription:</strong> " . $row["discription"] . "</p>";
    echo "<p class='card-infopr-5'><strong>Address:</strong> " . $row["address"] . "</p>";
    echo "<p class='card-info'><strong>feature:</strong> ";
    foreach(json_decode($row["features"]) as $k=>$v):
      echo $v.', ';
    endforeach;
    echo "</p>";
    echo"";
    echo "</div>";
    echo "</div>";
  }
  echo "</div>";

?>

      <footer class="text-center text-lg-left bg-light ">

        <section
          class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom text-white"
        >
          <div class="me-5 ps-4 d-none d-lg-block font-weight-bold">
            <span>abc@example.com</span>
          </div>
          <div class="text-center d-none d-lg-block font-weight-bold">
            <span>+1 123 456 7890</span>
          </div>
        
          <div class="font-weight-bold">
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-facebook-f"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-twitter"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-google"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-linkedin"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-github"></i>
            </a>
          </div>
        </section>
        <section class="text-white">
          <div class="container text-center text-md-left  ">
            <div class="row">
              <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  <i class="fas fa-gem mr-3"></i>DORSIN
                </h6>
                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                </p>
              </div>
              <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Information
                </h6>
                <p>
                  <a href="#!" class="text-reset">Home</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">About us</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Contact us</a>
                </p>
              </div>
              <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Community
                </h6>
                <p>
                  <a href="#!" class="text-reset">FAQ</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Login</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Sign Up</a>
                </p>
              </div>
              <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-5 mt-5 pb-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Subscribe
                </h6>
                <p><i class="fas fa-home mr-3"></i> In an ideal world this text wouldn’t exist,
                  a client would acknowledge the importance of having web copy before the design starts.
                </p>
                <p>
                  <i class="fas fa-envelope mr-3"></i>
                  info@example.com
                </p>
              </div>
            </div>
          </div>
        </section>

        <div class="text-center p-4 bg-secondary text-white">
          <a class="text-reset font-weight-bold" href="https://mdbootstrap.com/">2022© Dorsin - Themesbrand</a>
        </div>
      </footer>
      <!--Start of Tawk.to Script-->
      <script type="text/javascript">
            var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
            (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/63b58c05c2f1ac1e202ba7a8/1gluiltv8';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
            })();
            </script>
            <!--End of Tawk.to Script-->
</body>
</html>