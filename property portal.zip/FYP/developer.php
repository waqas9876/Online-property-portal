<?php
$conn = mysqli_connect('localhost','root','','fyp');
if(isset($_POST['sub'])){
    
    if(!empty($_POST['email'])){
        $name=$_POST['name'];
        $developer=$_POST['developer'];
        $email=$_POST['email'];
        $phone_no=$_POST['phone_no'];
        $q='SELECT * from developer where email="'.$email.'"';
        $qr=mysqli_query($conn,$q);
        $row=mysqli_num_rows($qr);
        if($row < 1){
            $q1='INSERT INTO developer SET
                `email`="'.$email.'",
                `name`="'.$name.'",
                `developer`="'.$developer.'",
                `phone_no`="'.$phone_no.'"
            ';
            // die($q1);
            $qr1=mysqli_query($conn,$q1);
            if($qr1){
                $_SESSION['s']='new login inserted';
                header('location: developer.php');
                echo($_SESSION['s']);
            }
        }else{
            $_SESSION['e']='Something Wrong';
                header('location: list property.php');
        }
    }else{
        $_SESSION['e']='Fil all the fields';
        header('location: developer.php');
    }
    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>developer</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Online Property</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="property.php">Projects</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="map.php">House Plan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="developer.php">Developers</a>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="login.php">Log Out</a></button>
          </form>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="list property.php">List Property</a></button>
          </form>
        </div>
      </nav>


        <form class="container" method="POST" enctype="multipart/form-data">
            <div class="form-row mt-5">
                <div class="col-md-6 mb-3">
                <label for="validationTooltip01">Enter Name</label>
                <input type="text" class="form-control" name="name" id="validationTooltip01" placeholder="First name" value="" required>
                <div class="valid-tooltip">
                    Looks good!
                </div>
                </div>
                <div class="col-md-6 mb-3">
                <label for="validationTooltip02">Enter Email</label>
                <input type="text" class="form-control" name="email" id="validationTooltip02" placeholder="Last name" value="" required>
                <div class="valid-tooltip">
                    Looks good!
                </div>
                </div>
              </div>
              <div class="form-row">
                
                <div class="col-md-6 mb-3">
                <label for="validationTooltipUsername">Enter PhoneNo</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                    </div>
                    <input type="number" class="form-control" name="phone_no" id="validationTooltipUsername" placeholder="Phone no" aria-describedby="validationTooltipUsernamePrepend" required>
                </div>
                </div>
                
                <div class="col-md-6 mb-3">
                <label for="validationTooltip03">how many developers you need?</label>
                <select name="developer" class=" w-100 h-50">
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
                </select>
                </div>
                
            </div>
            <button class="btn btn-primary" name="sub" type="submit">Submit</button>
        </form>
        <br>
<?php
// if(isset($_POST['sub'])){
//     if(!empty($_POST['email'])){
//         $developer=$_POST['developer'];
//         $email=$_POST['email'];
//         $phone_no=$_POST['phone_no'];
//         $name=$_POST['name'];
//         $q='SELECT * from developer where developer="'.$developer.'"';
//         $qr=mysqli_query($conn,$q);
//         $row=mysqli_num_rows($qr);
//         if($row < 1){
//             $q1='INSERT INTO developer SET
//                 `name`="'.$name.'",
//                 `developer`="'.$developer.'",
//                 `email`="'.$email.'",
//                 `phone_no`="'.$phone_no.'"
//             ';
//             die('hsdgdhsa');
//             $qr1=mysqli_query($conn,$q1);
//             if($qr1){
//                 $_SESSION['s']='Your request for developers submitted we will contact you as soos as posible.';
//                 header('location: property.php');
//                 echo("<div class='text-center pt-3 pb-3 bg-primary'>");
//                 echo($_SESSION['s']);
//                 echo("</div>");
//             }
//     }else{
//         $_SESSION['e']='Fil all the fields';
//         // header('location: list property.php');
//     }
// }
// }
?>
    
</body>
</html>