<?php
$conn = mysqli_connect('localhost','root','','fyp');
if(isset($_POST['sub'])){
    
    if(!empty($_POST['price'])){
        $price=$_POST['price'];
        $discription=$_POST['discription'];
        $features=$_POST['features'];
        if(!empty($_FILES['f']['name'])){
            $n=$_FILES['f']['name'];
            $t=$_FILES['f']['type'];
            $s=$_FILES['f']['size'];
    
            $name=time().$n;
            if($s > 1000*1000*1){
                die('Please chose 1MB file');
            }      
            $move=move_uploaded_file($_FILES['f']['tmp_name'],'images/'.$name);
        
    }
        $k=array_map(function($index){
            return 'fet'.$index;
        },array_keys($features));
        $features=array_combine($k,$features);
        // print_r($features);
        // $abc=serialize($features);
        // echo(json_encode($features));
        // echo $abc;
        // die();
        $address=$_POST['address'];
        $title=$_POST['title'];
        // $file=$_POST['file'];
        $q='SELECT * from lpro where price="'.$price.'"';
        $qr=mysqli_query($conn,$q);
        $row=mysqli_num_rows($qr);
        if($row < 1){
            $q1='INSERT INTO lpro SET
                `price`="'.$price.'",
                `discription`="'.$discription.'",
                `features`=\''.json_encode($features).'\',
                `address`="'.$address.'",
                `title`="'.$title.'",
                `file`="'.$name.'",
                `status`="1"

            ';
            // die($q1);
            $qr1=mysqli_query($conn,$q1);
            if($qr1){
                $_SESSION['s']='new login inserted';
                header('location: property.php');
            }
        }else{
            $_SESSION['e']='Something Wrong';
                header('location: list property.php');
        }
    }else{
        $_SESSION['e']='Fil all the fields';
        header('location: list property.php');
    }
    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>list property</title>
    <style>
        .box{
        box-shadow: 10px 10px 10px lightgray;
        border: 0px solid;
        height: auto;
      }
    </style>
</head>
<body>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="box mt-5 container col-lg-8 mx-auto col-sm-12">
            <div class="row">
                <div class="col-lg-4"><input class="ml-5" type="file" name="f"></div>
                <div class="col-lg-4">
                    <select name="" id="" class="ml-5">
                        <option value="">Add property type</option>
                        <option value="">plot</option>
                        <option value="">house</option>
                        <option value="">shop</option>
                        <option value="">flat</option>
                        <option value="">other</option>
                    </select>
                </div>
                <div class="col-lg-4">
                    <input class="ml-5" name="price" type="text" placeholder="Add price">
                </div>
            </div>
            <hr>
            <div class="row mt-5">
                <div class="col-lg-4">
                    <div class="h2  ml-5">Add Property title</div>
                </div>
                <div class="col-lg-6 ml-5">
                    <textarea style="width: 100%;" name="title" id="" cols="50" rows="5"></textarea>
                </div>
            </div>
            <hr>
            <div class="row mt-5">
                <div class="col-lg-4">
                    <div class="h2  ml-5">Add Property Discription</div>
                </div>
                <div class="col-lg-6 ml-5">
                    <textarea style="width: 100%;" name="discription" id="" cols="50" rows="5"></textarea>
                </div>
            </div>
            <hr>
            <div class="row mt-5">
                <div class="col-lg-4">
                    <h2 class="ml-5">Add feather</h2>
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="Water"> Water</div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="Gas"> Gas</div>
    
                <br><br>
    
                <div class="col-lg-4">
                    
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="parking area"> parking area</div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="Electricity"> Electricity</div>
                
                <br><br>
    
                <div class="col-lg-4">
                    
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="road"> road</div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="Security staff"> Security Staff</div>
                
                <br><br>
    
                <div class="col-lg-4">
                    
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="CCTV cameras"> CCTV Cameras</div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="TV and internet"> tv and internet</div>
                
                <br><br>
    
                <div class="col-lg-4">
                    
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="hospital">  hospital</div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="Masjid"> Masjid</div>
                
                <br><br>
    
                <div class="col-lg-4">
                    
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="School"> School</div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox" name="features[]" value="College"> College</div>
                
                <br><br>
    
                <div class="col-lg-4">
                    
                </div>
                <div  class="col-lg-4 fa-solid mt-3"><input type="checkbox"  name="features[]" value="Public transport">  Public Transport</div>
            </div>
            <hr>
            <div class="row mt-5">
                <div class="col-lg-4">
                    <div class="h2  ml-5">Add Address</div>
                </div>
                <div class="col-lg-6 ml-5">
                    <textarea style="width: 100%;" name="address" id="" cols="50" rows="3"></textarea>
                </div>
            </div>
            <div class="col-lg-12 mt-4 btn pull-right"> <input name="sub" type="submit"></div>
    
    
        </div>

    </form>
</body>
</html>