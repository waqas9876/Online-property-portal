<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Projects</title>
    <style>
        .main1{
            background-image: url("banner2.jpg");
            height: 500px;
        }
        .tb{
            border-radius: 10px;
            
        }
        .w{
            border: none;
            width: 210px;
            margin: 0px auto;
            
        }
        .tbtn input{
          border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .tbtn input:hover{
          border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
            transition: 0.5s;
        }
        footer{
          background-image: url("footer-img.jpg");
          background-repeat: no-repeat;
          background-size: 100% 87%;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Online Property</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Rent</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Buy</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Sell</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Investment</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                type
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit">List Property</button>
          </form>
        </div>
      </nav>

      <div class="main1">
        <div style="padding-top: 200px;" class="heading">
            <h1 class="text-center text-white">Find your Dream Home, Office, Shop or Plot in Pakistan</h1>
        </div>
        <div class="box">
            <table class="table table-borderless bg-light container mx-auto tb col-lg-10 col-md-8 col-sm-4 table-responsive w-100">
                <thead>
                  <tr class="text-center">
                    <th scope="col">Property Purpose</th>
                    <th scope="col">All Cities</th>
                    <th scope="col">Location</th>
                    <th scope="col">Property Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="text-center">
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td class="tbtn">
                      <input class="pl-2 pr-2 " type="submit">
                  </td>
                  </tr>
                </tbody>
              </table>
        </div>
      </div>



          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li class="bg-dark" data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li class="bg-dark" data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li class="bg-dark" data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="container-fluid mt-5 pb-5 bg-light">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title text-muted  mt-3 fw-bolder"><p>UI & UX Design</p></div>
                      <div class="card-text"><h4>Doing a cross country road trip</h4></div>
                      <p class="text-muted">We packed her seven versalia, put her initial into the belt and
                        made herself on the way..</p>
                        <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                        <button class="cta">
                          <span class="hover-underline-animation"> Read More </span>
                          <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                            <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                          </svg>
                        </button>
                    </div>
                  </div>
                </div>
                
                <div class="col-lg-4 col-md-6 col-sm-12  pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house2.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title  text-muted mt-3 fw-bolder"><p>Digital Marketing</p></div>
                      <div class="card-text "><h4>New exhibition at our Museum</h4></div>
                      <p class="text-muted">Pityful a rethoric question ran over her cheek, then she continued her way...</p>
                        <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                      <button class="cta">
                        <span class="hover-underline-animation"> Read More </span>
                        <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                          <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house3.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title text-muted mt-3 fw-bolder"><p>Travelling</p></div>
                      <div class="card-text"><h4>Why are so many people</h4></div>
                      <p class="text-muted">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
                      <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                      <button class="cta">
                        <span class="hover-underline-animation"> Read More </span>
                        <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                          <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                        </svg>
                      </button>
                    </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="container-fluid mt-5 mb-5 bg-light">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title text-muted  mt-3 fw-bolder"><p>UI & UX Design</p></div>
                      <div class="card-text"><h4>Doing a cross country road trip</h4></div>
                      <p class="text-muted">We packed her seven versalia, put her initial into the belt and
                        made herself on the way..</p>
                        <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                        <button class="cta">
                          <span class="hover-underline-animation"> Read More </span>
                          <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                            <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                          </svg>
                        </button>
                    </div>
                  </div>
                </div>
                
                <div class="col-lg-4 col-md-6 col-sm-12  pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house2.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title  text-muted mt-3 fw-bolder"><p>Digital Marketing</p></div>
                      <div class="card-text "><h4>New exhibition at our Museum</h4></div>
                      <p class="text-muted">Pityful a rethoric question ran over her cheek, then she continued her way...</p>
                      <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                      <button class="cta">
                        <span class="hover-underline-animation"> Read More </span>
                        <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                          <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house3.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title text-muted mt-3 fw-bolder"><p>Travelling</p></div>
                      <div class="card-text"><h4>Why are so many people</h4></div>
                      <p class="text-muted">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
                      <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                      <button class="cta">
                        <span class="hover-underline-animation"> Read More </span>
                        <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                          <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                        </svg>
                      </button>
                    </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="container-fluid mt-5 mb-5 bg-light">
            <div class="container">
              <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title text-muted  mt-3 fw-bolder"><p>UI & UX Design</p></div>
                      <div class="card-text"><h4>Doing a cross country road trip</h4></div>
                      <p class="text-muted">We packed her seven versalia, put her initial into the belt and
                        made herself on the way..</p>
                        <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                        <button class="cta">
                          <span class="hover-underline-animation"> Read More </span>
                          <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                            <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                          </svg>
                        </button>
                    </div>
                  </div>
                </div>
                
                <div class="col-lg-4 col-md-6 col-sm-12  pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house2.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title  text-muted mt-3 fw-bolder"><p>Digital Marketing</p></div>
                      <div class="card-text "><h4>New exhibition at our Museum</h4></div>
                      <p class="text-muted">Pityful a rethoric question ran over her cheek, then she continued her way...</p>
                      <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                      <button class="cta">
                        <span class="hover-underline-animation"> Read More </span>
                        <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                          <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
                  <div class="card border-5">
                    <img style="height: 300px;" src="house3.jpg" alt="">
                    <div class="card-boody">
                      <div class="card-title text-muted mt-3 fw-bolder"><p>Travelling</p></div>
                      <div class="card-text"><h4>Why are so many people</h4></div>
                      <p class="text-muted">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
                      <a href=""><i class="fa-solid fa-bed pr-5 pl-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-bath pl-5 pr-5 text-dark"></i></a>
                        <a href=""><i class="fa-solid fa-message pl-5 text-dark"></i></a>
                     <br>
                      <button class="cta">
                        <span class="hover-underline-animation"> Read More </span>
                        <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                          <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                        </svg>
                      </button>
                    </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon bg-dark" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon bg-dark" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    
<br>
<div class="container-fluid bg-light">
  <div class="container">
    <div class="row">
      <div class="col-lg-5 col-md-5 col-sm-12 col-xm-12">
        <h4 class="fs-3">A digital web design studio creating modern & engaging online experiences</h4>
        <br>
       
        <p class="text-muted fs-5">Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
       
       <br>
        <ul>
          <li class="text-muted">We put a lot of effort in design.</li>
          <li class="text-muted">The most important ingredient of successful website.</li>
          <li class="text-muted">Sed ut perspiciatis unde omnis iste natus error sit.</li>
          <li class="text-muted">Submit Your Orgnization.</li>
        </ul>
        <button class="btn2"> Learn More!
        </button>

      </div>
      
      <div class="col-lg-6 col-md-6 col-sm-12 col-xm-12 ms-2">
        <img src="mobilepic.png" alt="" style="width: 25vw; height: 30vw; float: right;">

      </div>
    </div>
  </div>
</div>
<br><br>
      <footer class="text-center text-lg-left bg-light ">

        <section
          class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom text-white
        >
          <div class="me-5 ps-4 d-none d-lg-block font-weight-bold">
            <span>abc@example.com</span>
          </div>
          <div class="text-center d-none d-lg-block font-weight-bold">
            <span>+1 123 456 7890</span>
          </div>
        
          <div class="font-weight-bold">
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-facebook-f"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-twitter"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-google"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-linkedin"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-github"></i>
            </a>
          </div>
        </section>
        <section class="text-white">
          <div class="container text-center text-md-left  ">
            <div class="row">
              <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  <i class="fas fa-gem mr-3"></i>Property Portal
                </h6>
                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                </p>
              </div>
              <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Information
                </h6>
                <p>
                  <a href="#!" class="text-reset">Home</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">About us</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Contact us</a>
                </p>
              </div>
              <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Community
                </h6>
                <p>
                  <a href="#!" class="text-reset">FAQ</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Login</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Sign Up</a>
                </p>
              </div>
              <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-5 mt-5 pb-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Subscribe
                </h6>
                <p><i class="fas fa-home mr-3"></i> In an ideal world this text wouldn’t exist,
                  a client would acknowledge the importance of having web copy before the design starts.
                </p>
                <p>
                  <i class="fas fa-envelope mr-3"></i>
                  info@example.com
                </p>
              </div>
            </div>
          </div>
        </section>

        <div class="text-center p-4 bg-secondary text-white">
          <a class="text-reset font-weight-bold" href="https://mdbootstrap.com/">2022© Property Portal - Themesbrand</a>
        </div>
      </footer>
      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</body>
</html>