<?php
$conn = mysqli_connect('localhost','root','','fyp');
session_start();
// if (isset($_POST['delete'])) {
//     // $projectId = mysqli_real_escape_string($c, $_POST['delete']);
//     $q = "UPDATE lpro SET status='0' WHERE status='1'";
//     $result = mysqli_query($conn, $q);
//     if ($result) {
//       $_SESSION['s']='Project Mark as Delete!';
//       header('location: property.php');
//     } 
//   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
    <style>
      .card {
    width: 300px;
    /* text-align: center; */
    margin: auto;
    padding: 10px;
    border: 1px solid #ccc;
    margin-top: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
}

.card-image {
    width: 100%;
    height: auto;
    border-radius: 5px;
    margin-bottom: 10px;
}

.card-title {
    font-size: 18px;
    margin-top: 0;
}

.card-info {
    margin-bottom: 5px;
}
    </style>
</head>
<body>
<?php
      $q = "SELECT * FROM lpro";
      $qr = mysqli_query($conn, $q);
      echo"<div class='container'>";
      echo"<h1 class='mt-5'> Property </h1>";

        echo "<div class='card-container row'>";

        while ($row = mysqli_fetch_assoc($qr)) {
            echo "<div class='card'>";
            echo "<img src='images/" . $row["file"] . "' alt='" . $row["file"] . "' class='card-image'>";
            echo "<div class='card-content'>";
            echo "<h3 class='card-title'>" . $row["title"] . "</h3>";
            echo "<p class='card-info'><strong>ID:</strong> " . $row["id"] . "</p>";
            echo "<p class='card-info'><strong>Price:</strong> " . $row["price"] . "</p>";
            echo "<p class='card-info'><strong>Discription:</strong> " . $row["discription"] . "</p>";
            echo "<p class='card-info'><strong>feature:</strong> ";
            foreach(json_decode($row["features"]) as $k=>$v):
              echo $v.', ';
            endforeach;
            echo "</p>";
            echo"<div class='row'>";
            
            echo"<a href='property-detail.php?id=" .$row['id']. "'><button class='btn btn-primary ml-5 btn-lg' type='submit' name=''>view</button></a>";
            if($_SESSION['admin']['user_type'] == 'admin'){
              echo "<form method='post'>
                <button class='btn btn-danger btn-lg ml-5 delete-btn' type='submit' value=" . $row["status"] . " name='delete'>delete</button>
              </form>";
            }
            echo"</div>";
            echo "</div>";
            echo "</div>";
          }
          echo "</div>";
        echo"</div>";

if (isset($_POST['delete'])) {
  // $projectId = mysqli_real_escape_string($c, $_POST['delete']);
  $q = "UPDATE lpro SET status='0' WHERE status='1'";
  $result = mysqli_query($conn, $q);
  if ($result) {
    $_SESSION['s']='Project Mark as Delete!';
    
  } 
}

?>
<?php


// Define the delete query
$query = "DELETE FROM lpro WHERE status='0'";

// Execute the delete query
if (mysqli_query($conn, $query)) {
    // echo "Record deleted successfully.";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}


?>

<?php
$q = "SELECT * FROM developer";
$qr = mysqli_query($conn, $q);
echo"<div class='container'>";
echo"<h1 class='mt-5'> Request For Developers </h1>";

  echo "<div class='card-container row'>";

  while ($row = mysqli_fetch_assoc($qr)) {
      echo "<div class='card'>";
      echo "<div class='card-content'>";
      echo "<h3 class='card-Name text-center'>" . $row["name"] . "</h3>";
      echo "<p class='card-info'><strong>Email:</strong> " . $row["email"] . "</p>";
      echo "<p class='card-info'><strong>Phone_no:</strong> " . $row["phone_no"] . "</p>";
      echo "<p class='card-info'><strong>Developer:</strong> " . $row["developer"] . "</p>";
      echo "</p>";
      echo "</div>";
      echo "</div>";
    }
    echo "</div>";
  echo"</div>";

?>
<div></div>
</body>
</html>