<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fyp";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the image by ID


// Close the database connection

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>map</title>
    <style>
        footer{
          background-image: url("footer-img.jpg");
          background-repeat: no-repeat;
          background-size: 100% 87%;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Online Property</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="property.php">Projects</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="map.php">Need Map For House?</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="developer.php">Need Developers For House?</a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link" href="#">Investment</a>
            </li> -->
            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                type
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li> -->
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="login.php">Log Out</a></button>
          </form>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="list property.php">List Property</a></button>
          </form>
        </div>
      </nav>

    <form method="post" class="border border-dark container mt-5 rounded p-5 mb-5">
        
        <div class="col-lg-12 text-center ">
            <h1 class="text-primary ">Select the area for House map in marla</h1>
            <select name="id" class="w-25 mt-5">
                <option value="3" selected>select the marla</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
            </select>
<!-- <input type="text" name="id"> -->
            <input class="btn-primary" type="submit" value="Submit" name="sub" />
        </div>
    <?php
    if (isset($_POST['sub'])) {
        $selectedID = $_POST['id'];
    
        $q = "SELECT * FROM map WHERE id = $selectedID";
        $qr = mysqli_query($conn, $q);
        
    
        while ($row = mysqli_fetch_assoc($qr)) {
            echo "<div class='container w-50  mt-5 text-center'>";
            echo "<img class='w-50 h-25' src='images/" . $row["image"] . "' alt='" . $row["image"] . "' class='card-image w-50 h-50 m-auto'>";
            echo "</div>";
        }
       
    } 
?>
    </form>

    <footer class="text-center text-lg-left bg-light ">

          <section
            class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom text-white"
          >
            <div class="me-5 ps-4 d-none d-lg-block font-weight-bold">
              <span>abc@example.com</span>
            </div>
            <div class="text-center d-none d-lg-block font-weight-bold">
              <span>+1 123 456 7890</span>
            </div>

            <div class="font-weight-bold">
              <a href="" class="ml-4 text-reset">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="" class="ml-4 text-reset">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="" class="ml-4 text-reset">
                <i class="fab fa-google"></i>
              </a>
              <a href="" class="ml-4 text-reset">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="" class="ml-4 text-reset">
                <i class="fab fa-linkedin"></i>
              </a>
              <a href="" class="ml-4 text-reset">
                <i class="fab fa-github"></i>
              </a>
            </div>
          </section>
          <section class="text-white">
            <div class="container text-center text-md-left  ">
              <div class="row">
                <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-5 mt-5">
                  <h6 class="text-uppercase font-weight-bold mb-4">
                    <i class="fas fa-gem mr-3"></i>Property Portal
                  </h6>
                  <p>
                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  </p>
                </div>
                <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                  <h6 class="text-uppercase font-weight-bold mb-4">
                    Information
                  </h6>
                  <p>
                    <a href="#!" class="text-reset">Home</a>
                  </p>
                  <p>
                    <a href="#!" class="text-reset">About us</a>
                  </p>
                  <p>
                    <a href="#!" class="text-reset">Contact us</a>
                  </p>
                </div>
                <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                  <h6 class="text-uppercase font-weight-bold mb-4">
                    Community
                  </h6>
                  <p>
                    <a href="#!" class="text-reset">FAQ</a>
                  </p>
                  <p>
                    <a href="#!" class="text-reset">Login</a>
                  </p>
                  <p>
                    <a href="#!" class="text-reset">Sign Up</a>
                  </p>
                </div>
                <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-5 mt-5 pb-5">
                  <h6 class="text-uppercase font-weight-bold mb-4">
                    Subscribe
                  </h6>
                  <p><i class="fas fa-home mr-3"></i> In an ideal world this text wouldn’t exist,
                    a client would acknowledge the importance of having web copy before the design starts.
                  </p>
                  <p>
                    <i class="fas fa-envelope mr-3"></i>
                    info@example.com
                  </p>
                </div>
              </div>
            </div>
          </section>

          <div class="text-center p-4 bg-secondary text-white">
          <a class="text-reset font-weight-bold" href="https://mdbootstrap.com/">2022© Property Portal - Themesbrand</a>
        </div>
</footer>
</body>
</html>
