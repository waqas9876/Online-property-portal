<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>home</title>
    <style>
        *{
            margin: 0px;
            padding: 0px;
        }
       
        .main1{
            background-image: url("banner2.jpg");
            height: 500px;
        }
        .w{
            border: none;
            width: 210px;
            margin: 0px auto;
            
        }
        .tb{
            border-radius: 10px;
        }
        .tbtn input{
          border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .tbtn input:hover{
          border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
            transition: 0.5s;
        }
        .box .sub1:hover{
            color: white;
            background-color: green;
            transition: 1s;
            border-radius: 0px 10px 0px 10px;
        }
        .bb{
            position: relative;
            margin: auto;
           left: 140px;
        } 
        .b1{
            margin-left: 10px;
            color: green;
            background-color: gainsboro;
            padding: 6px;
            border-radius: 10px 0px 10px 0px;
            font-weight: bold;
        }
        .b1:hover{
            color: white;
            background-color: green;
            transition: 1s;
            border-radius: 0px 10px 0px 10px;
        }
        /*.t1{
            font-size: 50px;
            position: relative;
            top: 130px;
            font-weight: bold;  
        }
        .box{
            
            border: 1px solid;
            height: 100px;
            position: relative;
            top: 150px;
            
            background-color: #fff;
            margin-left: auto;
            margin-right: auto;
        }
        .box .input1{
            width: 300px;
            height: 40px;
            margin-top: 20px;
            background-color: white;
            margin-left: 0px;
        }
        .box .input2{
            width: 500px;
            height: 40px;
            margin-top: 20px;
            background-color: white;
        }
        .box .sub1{
            padding: 7px;
            border-radius: 10px;
            font-weight: bold;
            margin-left: 15px;
            border-radius: 10px 0px 10px 0px;
        }
        */

        .box1{
            background-image: url("lahore.jpg");
            height: 350px;
            width: 550px;
            background-size: cover;
            margin-left: 70px;
            border-radius: 0px 20px 0px 20px;
        }
        .box1:hover{
            width: 600px;
            filter: brightness(80%);
            height: 370px;
            transition: 1s;
        }
        .box2{
            background-image: url("islamabad.jpg");
            height: 350px;
            background-size: cover;
            width: 550px;
            margin-left: 60px;
            border-radius: 0px 20px 0px 20px;
        }
        .box2:hover{
            width: 600px;
            height: 370px;
            filter: brightness(80%);
            transition: 1s;
        }
        
        .box1 input{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .box2 input{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .box3 input{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .box4 input{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .box5 input{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: green;
            border: 1px solid green;
        }
        .box1 input:hover{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
        }
        .box2 input:hover{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
        }
        .box3 input:hover{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
        }
        .box4 input:hover{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
        }
        .box5 input:hover{
            border-radius: 5px;
            font-weight: bolder;
            padding: 5px;
            color: #fff;
            border: 1px solid #fff;
            background-color: green;
        }
        .box3{
            background-image: url("karachi1.jpg");
            height: 200px;
            background-size: cover;
            width: 300px;
            margin-left: 120px;
        }
        .box3:hover{
            width: 320px;
            height: 220px;
            filter: brightness(80%);
            transition: 1s;
        }
        .box4{
            background-image: url("rawalpindi.jpg");
            height: 200px;
            background-size: cover;
            width: 300px;
            margin-left: 60px;
            
        }
        .box4:hover{
            width: 320px;
            height: 220px;
            filter: brightness(80%);
            transition: 1s;
        }
        .box5{
            background-image: url("peshawer.jpg");
            height: 200px;
            width: 300px;
            background-repeat: no-repeat;
            background-size: cover;
            margin-left: 60px;

           
        }
        .box5:hover{
            width: 320px;
            height: 220px;
            filter: brightness(80%);
            transition: 1s;
        }
        .border1{
            border-radius: 0px 20px 0px 20px;
        }
        .box6{
            border: 1px solid;
        }
        .banner{
            background-image: url("banner.jpg");
            height: 200px;
            background-size: cover;
        }
    </style>

</head>
<body>
    <div class="main col-sm-12">
            
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Online Property</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="property.php">Projects</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="map.php">House Plan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="developer.php">Developer</a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link" href="#">Investment</a>
            </li> -->
            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                type
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li> -->
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="login.php">Log Out</a></button>
          </form>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit"><a href="list property.php">List Property</a></button>
          </form>
        </div>
      </nav>

      <div class="main1">
        <div style="padding-top: 200px;" class="heading">
            <h1 class="text-center text-white">Find your Dream Home, Office, Shop or Plot in Pakistan</h1>
        </div>
        <div class="box">
            <table class="table table-borderless bg-light container mx-auto tb col-lg-10 col-md-8 col-xm-6 table-responsive">
                <thead>
                  <tr class="text-center">
                    <th scope="col">Property Purpose</th>
                    <th scope="col">All Cities</th>
                    <th scope="col">Location</th>
                    <th scope="col">Property Type</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="text-center">
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td><select class="form-control w" id="exampleFormControlSelect1">
                        <option selected>All Purpose</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                      </select>
                    </td>
                    <td class="tbtn">
                      <input class="pl-2 pr-2 " type="submit">
                  </td>
                  </tr>
                </tbody>
              </table>
              <div class="row col-lg-5 mt-4 bb">
                <input class="b1" type="submit" value="Rent">
                <input class="b1" type="submit" value="Sell">
                <input class="b1" type="submit" value="Inverstment">
            </div>
        </div>
      </div>
      <br>

    <div class="main2 col-sm-12">
        <h1 class="text-center pt-5">Find Properties In Your City</h1>
    </div>
    <div class="row col-lg-12 col-sm-12">
        <div class="box1">
            <input class="m-5 pl-3 pr-3 " type="submit" value="lahore">
        </div>
        <div class="box2">
            <input class="m-5 pl-3 pr-3 " type="submit" value="islamabad">
        </div>
    </div>
    <div class="row col-lg-12 col-sm-12">
        <div class="box3 border1 mt-5">
            <input class="m-3 pl-3 pr-3 " type="submit" value="Karachi">
        </div>
        <div class="box4 border1 mt-5">
            <input class="m-3 pl-2 pr-3 " type="submit" value="Rawalpindi">
        </div>
        <div class="box5 border1 mt-5">
            <input class="m-3 pl-2 pr-3 " type="submit" value="Peshawar">
        </div>
    </div>
    <br><br>
    <div class="box6 container col-lg-10 col-md-10 col-sm-10 col-xm-10">
        <h1 class="p-4">Welcome to RealProperty.pk</h1>
        <p>RealProperty is the fastest-growing company in Pakistan's online real estate sector, 
            introducing the most straightforward property search form to find homes, flats, apartments,
            houses for sale, purchase, and rent. We only list properties to buy, sell, 
            or renting out after comprehensive verification, and are near the prevailing market rates.
            We discourage fake listings and property listings demanding inflated prices.
            You can select your preferred properties for sale and rent with convenience in a
            clutter-free environment. Realistically, buying a home is a hard decision — We at
            RealProperty help transform it into your safest, high yield investment real estate deals.
            We can also help you with how to secure home financing and step by step property registration process.</p>
            <p>RealProperty is the fastest-growing company in Pakistan's online real estate sector, 
                introducing the most straightforward property search form to find homes, flats, apartments,
                houses for sale, purchase, and rent. We only list properties to buy, sell, 
                or renting out after comprehensive verification, and are near the prevailing market rates.
                We discourage fake listings and property listings demanding inflated prices.
                You can select your preferred properties for sale and rent with convenience in a
                clutter-free environment. Realistically, buying a home is a hard decision — We at
                RealProperty help transform it into your safest, high yield investment real estate deals.
                We can also help you with how to secure home financing and step by step property registration process.</p>
                <p>RealProperty is the fastest-growing company in Pakistan's online real estate sector, 
                    introducing the most straightforward property search form to find homes, flats, apartments,
                    houses for sale, purchase, and rent. We only list properties to buy, sell, 
                    or renting out after comprehensive verification, and are near the prevailing market rates.
                    We discourage fake listings and property listings demanding inflated prices.
                    You can select your preferred properties for sale and rent with convenience in a
                    clutter-free environment. Realistically, buying a home is a hard decision — We at
                    RealProperty help transform it into your safest, high yield investment real estate deals.
                    We can also help you with how to secure home financing and step by step property registration process.</p>
    </div>
    <br>
    <div class="banner col-lg-12 col-md-12">
          
    </div>
    <br>
    <div class="container-fluid mt-5 mb-5 bg-light">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
              <div class="card border-5">
                <img style="height: 300px;" src="house.jpg" alt="">
                <div class="card-boody">
                  <div class="card-title text-muted  mt-3 fw-bolder"><p>UI & UX Design</p></div>
                  <div class="card-text"><h4>Doing a cross country road trip</h4></div>
                  <p class="text-muted">We packed her seven versalia, put her initial into the belt and
                     made herself on the way..</p>
                     <button class="cta">
                      <span class="hover-underline-animation"> Read More </span>
                      <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                        <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                      </svg>
                    </button>
                </div>
              </div>
            </div>
            
            <div class="col-lg-4 col-md-6 col-sm-12  pt-5">
              <div class="card border-5">
                <img style="height: 300px;" src="house2.jpg" alt="">
                <div class="card-boody">
                  <div class="card-title  text-muted mt-3 fw-bolder"><p>Digital Marketing</p></div>
                  <div class="card-text "><h4>New exhibition at our Museum</h4></div>
                  <p class="text-muted">Pityful a rethoric question ran over her cheek, then she continued her way...</p>
                  <button class="cta">
                    <span class="hover-underline-animation"> Read More </span>
                    <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                      <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                    </svg>
                  </button>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-12 pt-5">
              <div class="card border-5">
                <img style="height: 300px;" src="house3.jpg" alt="">
                <div class="card-boody">
                  <div class="card-title text-muted mt-3 fw-bolder"><p>Travelling</p></div>
                  <div class="card-text"><h4>Why are so many people</h4></div>
                  <p class="text-muted">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
                  <button class="cta">
                    <span class="hover-underline-animation"> Read More </span>
                    <svg id="arrow-horizontal" xmlns="http://www.w3.org/2000/svg" width="30" height="10" viewBox="0 0 46 16">
                      <path id="Path_10" data-name="Path 10" d="M8,0,6.545,1.455l5.506,5.506H-30V9.039H12.052L6.545,14.545,8,16l8-8Z" transform="translate(30)"></path>
                    </svg>
                  </button>
                </div>
            </div>
          </div>
          </div>
        </div>
      </div>






<br><br>
    <footer class="text-center text-lg-left bg-light ">

        <section
          class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
        >
          <div class="me-5 ps-4 d-none d-lg-block font-weight-bold">
            <span>abc@example.com</span>
          </div>
          <div class="text-center d-none d-lg-block font-weight-bold">
            <span>+1 123 456 7890</span>
          </div>
         
          <div class="font-weight-bold">
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-facebook-f"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-twitter"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-google"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-linkedin"></i>
            </a>
            <a href="" class="ml-4 text-reset">
              <i class="fab fa-github"></i>
            </a>
          </div>
        </section>
        <section style="background-color: rgb(32, 31, 31);" class="text-white">
          <div class="container text-center text-md-left  ">
            <div class="row">
              <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  <i class="fas fa-gem mr-3"></i>DORSIN
                </h6>
                <p>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                </p>
              </div>
              <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Information
                </h6>
                <p>
                  <a href="#!" class="text-reset">Home</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">About us</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Contact us</a>
                </p>
              </div>
              <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-5 mt-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Community
                </h6>
                <p>
                  <a href="#!" class="text-reset">FAQ</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Login</a>
                </p>
                <p>
                  <a href="#!" class="text-reset">Sign Up</a>
                </p>
              </div>
              <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-5 mt-5 pb-5">
                <h6 class="text-uppercase font-weight-bold mb-4">
                  Subscribe
                </h6>
                <p><i class="fas fa-home mr-3"></i> In an ideal world this text wouldn’t exist,
                   a client would acknowledge the importance of having web copy before the design starts.
                </p>
                <p>
                  <i class="fas fa-envelope mr-3"></i>
                  info@example.com
                </p>
              </div>
            </div>
          </div>
        </section>
      
        <div class="text-center p-4 bg-secondary text-white">
          <a class="text-reset font-weight-bold" href="https://mdbootstrap.com/">2022© Dorsin - Themesbrand</a>
        </div>
        
      </footer>
      
              <!--Start of Tawk.to Script-->
      <script type="text/javascript">
      var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
      (function(){
      var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
      s1.async=true;
      s1.src='https://embed.tawk.to/6418737431ebfa0fe7f3a561/1grvo60kk';
      s1.charset='UTF-8';
      s1.setAttribute('crossorigin','*');
      s0.parentNode.insertBefore(s1,s0);
      })();
      </script>
      <!--End of Tawk.to Script-->

      <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</body>
</html>