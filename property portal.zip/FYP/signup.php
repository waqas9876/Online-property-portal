<?php
session_start();
$conn = mysqli_connect('localhost','root','','fyp');
if(isset($_POST['signup'])){
    if(!empty($_POST['email'])){
        $email=$_POST['email'];
        $first_name=$_POST['first_name'];
        $last_name=$_POST['last_name'];
        $password=$_POST['password'];
        $user_type=$_POST['user_type'];
        $q='SELECT * from signup where email="'.$email.'"';
        $qr=mysqli_query($conn,$q);
        $row=mysqli_num_rows($qr);
        if($row < 1){
            $q1='INSERT INTO signup SET
                `first_name`="'.$first_name.'",
                `last_name`="'.$last_name.'",
                `email`="'.$email.'",
                `password`="'.$password.'",
                `user_type`="'.$user_type.'"
            ';
            $qr1=mysqli_query($conn,$q1);
            if($qr1){
                $_SESSION['s']='new login inserted';
                header('location: login.php');
            }
        }else{
            $_SESSION['e']='Something Wrong';
                header('location: signup.php');
        }
    }else{
        $_SESSION['e']='Fil all the fields';
        header('location: signup.php');
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
    <link rel="stylesheet" href="./style1.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>signup page</title>
    <style>
        .background-radial-gradient {
          background-color: hsl(218, 41%, 15%);
          background-image: radial-gradient(650px circle at 0% 0%,
              hsl(218, 41%, 35%) 15%,
              hsl(218, 41%, 30%) 35%,
              hsl(218, 41%, 20%) 75%,
              hsl(218, 41%, 19%) 80%,
              transparent 100%),
            radial-gradient(1250px circle at 100% 100%,
              hsl(218, 41%, 45%) 15%,
              hsl(218, 41%, 30%) 35%,
              hsl(218, 41%, 20%) 75%,
              hsl(218, 41%, 19%) 80%,
              transparent 100%);
        }
    
        #radius-shape-1 {
          height: 220px;
          width: 220px;
          top: -60px;
          left: -130px;
          background: radial-gradient(#44006b, #ad1fff);
          overflow: hidden;
        }
    
        #radius-shape-2 {
          border-radius: 38% 62% 63% 37% / 70% 33% 67% 30%;
          bottom: -60px;
          right: -110px;
          width: 300px;
          height: 300px;
          background: radial-gradient(#44006b, #ad1fff);
          overflow: hidden;
        }
    
        .bg-glass {
          background-color: hsla(0, 0%, 100%, 0.9) !important;
          backdrop-filter: saturate(200%) blur(25px);
        }
      </style>
</head>
<body>
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Dropdown
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Something else here</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">Disabled</a>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn btn-outline-success my-2 my-sm-0 pl-3 pr-3 mr-5" type="submit">List Property</button>
          </form>
        </div>
      </nav> -->

   <!-- Section: Design Block -->
   <form action="" method='post'>
     <section Action class="background-radial-gradient overflow-hidden">
       <div class="container px-4 py-5 px-md-5 text-center text-lg-start my-5">
         <div class="row gx-lg-5 align-items-center mb-5">
           <div class="col-lg-6 mb-5 mb-lg-0" style="z-index: 10">
             <img src="signup-vector.png" alt="signup-vector">
           </div>
     
           <div class="col-lg-6 mb-5 mb-lg-0 position-relative">
             <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
             <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>
     
             <div class="card bg-glass">
               <div class="card-body px-4 py-5 px-md-5">
                 <form>
                   <h1>Creat Account</h1> 
                   <!-- 2 column grid layout with text inputs for the first and last names -->
                   <div class="row">
                     <div class="col-md-6 mb-4">
                       <div class="form-outline">
                         <input type="text" name="first_name" id="form3Example1" class="form-control" />
                         <label class="form-label" for="form3Example1">First name</label>
                       </div>
                     </div>
                     <div class="col-md-6 mb-4">
                       <div class="form-outline">
                         <input type="text" name="last_name" id="form3Example2" class="form-control" />
                         <label class="form-label" for="form3Example2">Last name</label>
                       </div>
                     </div>
                   </div>
     
                   <!-- Email input -->
                   <div class="form-outline mb-4">
                     <input type="email" name="email" id="form3Example3" class="form-control" />
                     <label class="form-label" for="form3Example3">Email address</label>
                   </div>
     
                   <!-- Password input -->
                   <div class="form-outline mb-4">
                     <input type="password" name="password" id="form3Example4" class="form-control" />
                     <label class="form-label" for="form3Example4">Password</label>
                   </div>
     
                   <div class="form-outline mb-4">
                     <select name="user_type" id="" class="form-control">
                       <option value="user">User</option>
                       <option value="admin" selected>admin</option>
                     </select>
                     <label class="form-label" for="">Join as</label>
                   </div>
     
                   <!-- <div class="form-outline mb-4">
                     <input type="text" id="" class="form-control" />
                     <label class="form-label" for="">Phone No</label>
                   </div> -->
     
                   <!-- Checkbox -->
                   
     
                   <!-- Submit button -->
                   <button type="submit" name="signup" class="btn btn-primary btn-block mb-4">
                     Sign up
                   </button>
     
                   <!-- Register buttons -->
                   <div class="text-center">
                     <p>or sign up with:</p>
                     <button type="button" class="btn btn-link btn-floating mx-1">
                       <i class="fab fa-facebook-f"></i>
                     </button>
     
                     <button type="button" class="btn btn-link btn-floating mx-1">
                       <i class="fab fa-google"></i>
                     </button>
     
                     <button type="button" class="btn btn-link btn-floating mx-1">
                       <i class="fab fa-twitter"></i>
                     </button>
     
                     <button type="button" class="btn btn-link btn-floating mx-1">
                       <i class="fab fa-github"></i>
                     </button>
                   </div>
                 </form>
               </div>
             </div>
           </div>
         </div>
       </div>
     </section>
     
   </form>
<!-- Section: Design Block -->
</body>
</html>