<?php
session_start();
$conn = mysqli_connect('localhost','root','','fyp');

if (isset($_POST['sub'])) {
  if(!empty($_POST['email']) && !empty($_POST['password'])){
      $email=$_POST['email'];
      $password=$_POST['password'];
      $q= 'SELECT * from signup where email="'.$email.'" and password="'.$password.'"';
      
      $qr=mysqli_query($conn,$q);
      $record=mysqli_num_rows($qr);
      if($record > 0){
          $data=mysqli_fetch_assoc($qr);
          // print_r($data);
          $_SESSION['admin']=$data;
          header('location: home.php');
      }else{
          $_SESSION['e']='Email or password not Correct';
          header('location: login.php');
      }
  }else{
      $_SESSION['e']='please try again';
          header('location: login.php');
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="./fontawesome-free-6.0.0-web/css/all.css">
  <link rel="stylesheet" href="./style1.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <title>Login</title>
  <style>
    .background-radial-gradient {
      background-color: hsl(218, 41%, 15%);
      background-image: radial-gradient(650px circle at 0% 0%,
          hsl(218, 41%, 35%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%),
        radial-gradient(1250px circle at 100% 100%,
          hsl(218, 41%, 45%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%);
    }

    #radius-shape-1 {
      height: 220px;
      width: 220px;
      top: -60px;
      left: -130px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    #radius-shape-2 {
      border-radius: 38% 62% 63% 37% / 70% 33% 67% 30%;
      bottom: -60px;
      right: -110px;
      width: 300px;
      height: 300px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    .bg-glass {
      background-color: hsla(0, 0%, 100%, 0.9) !important;
      backdrop-filter: saturate(200%) blur(25px);
    }
  </style>
</head>
<body>
    <section class="background-radial-gradient overflow-hidden">
      <div class="container px-4 py-5 px-md-5 text-center text-lg-start my-5">
        <div class="row gx-lg-5 align-items-center mb-5">
          <div class="col-lg-6 mb-5 mb-lg-0" style="z-index: 10">
            <img src="login-vector.png" alt=" login vector">
          </div>
    
          <div class="col-lg-6 mb-5 mb-lg-0 position-relative">
            <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
            <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>
    
            <div class="card bg-glass">
              
                <h1 class="text-purple">Hey!Welcome</h1>

                <form class="needs-validation container" action="" method="POST">
                <!-- Email input -->
                    <div class="form-outline mb-4">
                      <input type="email" name="email" id="" class="form-control" />
                      <label class="form-label" for="">Email address</label>
                    </div>
                  
                    <!-- Password input -->
                    <div class="form-outline mb-4">
                      <input type="password" name="password" id="" class="form-control" />
                      <label class="form-label" for="">Password</label>
                    </div>
                  
                    <!-- Submit button -->
                    <button name="sub" value="submit" type="submit" class="btn btn-primary btn-block mb-4">submit</button>
                </form>
              
                <!-- Register buttons -->
                <!-- <div class="text-center">
                  <p>Not a member? <a href="signup.html">Register</a></p>
                  <p>or sign up with:</p>
                  <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-facebook-f"></i>
                  </button>
              
                  <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-google"></i>
                  </button>
              
                  <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-twitter"></i>
                  </button>
              
                  <button  type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-github"></i>
                  </button>
                </div> -->
            </div>
          </div>
        </div>
      </div>
    </section>
</body>
</html>




