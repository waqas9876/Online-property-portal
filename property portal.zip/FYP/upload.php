<?php
session_start();
$conn = mysqli_connect('localhost','root','','fyp');
if(isset($_POST['sub'])){
    if(!empty($_POST['id'])){
        $id=$_POST['id'];
        
    
        if(!empty($_FILES['f']['name'])){
            $n=$_FILES['f']['name'];
            $t=$_FILES['f']['type'];
            $s=$_FILES['f']['size'];
            $name=time().$n;
            if($s > 1000*1000*1){
                die('Please chose 1MB file');
            }      
            $move=move_uploaded_file($_FILES['f']['tmp_name'],'images/'.$name);
    }
       
        $q='SELECT * from map where image="'.$name.'"';
        $qr=mysqli_query($conn,$q);
        $row=mysqli_num_rows($qr);
        if($row < 1){
            $q1='INSERT INTO map SET
                `image`="'.$name.'",
                `id`="'.$id.'"
            ';
            $qr1=mysqli_query($conn,$q1);
            if($qr1){
                $_SESSION['s']='new login inserted';
                header('location: property.php');
            }
    }else{
        $_SESSION['e']='Fil all the fields';
        // header('location: list property.php');
    }
}
}
?>


<!-- upload_image.html -->
<html>
<body>
<form action="" method="POST" enctype="multipart/form-data">
    <h2>Enter ID</h2>
    <input type="text" name="id">
    <h2>Add Image</h2>
    <input  type="file" name="f" />
    <br><br>
    <input type="submit" value="Upload" name="sub" />
    
</form>
</body>
</html>