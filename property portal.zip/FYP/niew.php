<?php
//       $q = "SELECT * FROM lpro";
//       $qr = mysqli_query($conn, $q);

// echo "<div class='card-container'>";

// while ($row = mysqli_fetch_assoc($qr)) {
//     echo "<div class='container'>";
//     echo "<h3 class='card-title'>" . $row["title"] . "</h3>";
//     echo "<img class='w-50 h-50 col-sm-12'' src='images/" . $row["file"] . "' alt='" . $row["file"] . "' class='card-image'>";
//     echo "<div class='card-content'>";
//     echo "<p class='card-info'><strong>ID:</strong> " . $row["id"] . "</p>";
//     echo "<p class='card-info'><strong>Price:</strong> " . $row["price"] . "</p>";
//     echo "<p class='card-info'><strong>Discription:</strong> " . $row["discription"] . "</p>";
//     echo "<p class='card-info'><strong>feature:</strong> ";
//     foreach(json_decode($row["features"]) as $k=>$v):
//       echo $v.', ';
//     endforeach;
//     echo "</p>";
//     echo"";
//     echo "</div>";
//     echo "</div>";
//   }
//   echo "</div>";

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
        <?php
                $sel='SELECT * FROM lpro';
                $cq=mysqli_query($conn,$sel);
                while($fet=mysqli_fetch_assoc($cq)){
                ?>
                <tr>
                    <td><?=$fet['id']?></td>
                    <td><?=$fet['name']?></td>
                    <td><?=$fet['father']?></td>
                    <td><?=$fet['address']?></td>
                    <td><?=$fet['email']?></td>
                    <td><?=$fet['password']?></td>
                    <td>
                        <a href="3.edit.php?id=<?= $fet['id']?>"><button class="btn btn-success">Edit</button></a>
                        <a href="4.delete.php?delete=<?=$fet['id']?>"><button class="btn btn-danger">Delete</button></a>
                    </td>
                </tr>
                <?php }?>
        </tr>
    </table>
</body>
</html>